INSERT INTO Encargado VALUES    (11111111,'pedro','hernandes','pedrohernandes@gmail.com',1111111111,2222222222),
                                (22222222,'juan','rodriguez','ramonrodriguezzz@gmail.com',1111133333,NULL),
                                (33333333,'martin','martines','martinmartines_xd@gmail.com',1111144444,9999999999),
                                (44444444,'gabriel','alejandro','alejandrogabriel@gmail.com',8888888888,NULL),
                                (55555555,'maria','ladelbarrio','marialadelbarrio124@gmail.com',5555555555,NULL);

INSERT INTO Bar VALUES          (1,'wallinton 67',200,11111111),
                                (2,'mantequilla 0800',400,22222222),
                                (3,'av salame 980',500,33333333),
                                (4,'juan errique pinti 68',800,44444444),
                                (5,'crovara y cristiania 102',1000,55555555);

INSERT INTO Banda VALUES        (1,'metal y ka','rock',4),
                                (2,'los enanitos fluor','rock-pop',6),
                                (3,'garcia charly alfredo','rock',1),
                                (4,'paul maccarne','rock-pop',1),
                                (5,'philips collin','rock-pop',1);

INSERT INTO Recital VALUES      (1600,'2022/07/01',1,1),
                                (7500,'2022/07/04',1,2),
                                (7500,'2022/07/04',2,2),
                                (2400,'2022/08/06',4,3),
                                (3000,'2022/08/09',5,4),
                                (999,'2022/09/15',3,5);

INSERT INTO Cancion VALUES      ('Entro Sandman','es la luz',NULL,3.5,1),
                                ('lamento peruano','Big bang',NULL,4,2),
                                ('no me dejan entrar','clix antiguos',NULL,4.16,3),
                                ('die and let live','red rose speedrun',NULL,3.13,4),
                                ('dificil love','hits',NULL,4,5);