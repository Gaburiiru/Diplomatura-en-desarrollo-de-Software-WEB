Es de suma importancia ejecutar todo lo descomprimido en una sola carpeta, para lograr una gratificante experiencia.
1.cuando se crea la bd aparece un mensaje raro por parte de sqlite3, pero funca, vos segui para adelante nomas.
